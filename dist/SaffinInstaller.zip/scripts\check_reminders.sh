#!/usr/bin/env bash
# Simple reminder runner for Saffin Assistant
PYTHON=$(which python3 || which python)
BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"

# Run reminders
"$PYTHON" "$BASE_DIR/scripts/assistant.py" reminders

# On Sundays, also prompt for review (optional)
if [ "$(date +%A)" = "Sunday" ]; then
  "$PYTHON" "$BASE_DIR/scripts/assistant.py" ask "It's Sunday! Should I do my weekly review now?"
fi
