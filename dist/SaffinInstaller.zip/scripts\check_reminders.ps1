$BaseDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$pythonCmd = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $pythonCmd) {
    Write-Host "Python not found in PATH. Ensure Python is installed and available as 'python'."
    exit 1
}
$Python = $pythonCmd.Source

Start-Process -NoNewWindow -FilePath $Python -ArgumentList "$BaseDir\scripts\assistant.py reminders" -Wait

if ((Get-Date).DayOfWeek -eq 'Sunday') {
    Write-Host "📋 Sunday reminder: running weekly review generator"
    Start-Process -NoNewWindow -FilePath $Python -ArgumentList "$BaseDir\scripts\saffin.py review" -Wait
}
